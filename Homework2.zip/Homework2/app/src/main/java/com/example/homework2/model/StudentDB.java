package com.example.homework2.model;

import java.lang.reflect.GenericArrayType;
import java.util.ArrayList;

public class StudentDB {
    private static final StudentDB ourInstance = new StudentDB();

    private ArrayList<Student> mStudentList;

    static public StudentDB getInstance() { return ourInstance; }

    private StudentDB() { createStudentObjects(); }

    public ArrayList<Student> getStudentList() { return mStudentList; }

    public void setStudentList(ArrayList<Student> studentList) { mStudentList = studentList; }

    protected void createStudentObjects(){
        Student student = new Student("Marco", "Salinas", 1997);
        ArrayList<Course> courses = new ArrayList<Course>();
        courses.add(new Course("CPSC411", "B+"));
        courses.add(new Course("CPSC362", "A"));
        courses.add(new Course("MATH270B", "C-"));
        student.setCourses(courses);
        mStudentList = new ArrayList<Student>();
        mStudentList. add(student);

        student = new Student("Frank", "Galindo", 6589);
        courses = new ArrayList<Course>();
        courses.add(new Course("CPSC223J", "A"));
        student.setCourses(courses);
        mStudentList.add(student);
    }
}
