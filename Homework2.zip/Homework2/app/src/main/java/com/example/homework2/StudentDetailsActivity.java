package com.example.homework2;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;

import com.example.homework2.model.Student;
import com.example.homework2.model.StudentDB;

public class StudentDetailsActivity extends AppCompatActivity {

    protected Menu detailMenu;
    protected int studentIndex;
    protected Student sObj;
    //protected final String TAG = "Detail Screen";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //Log.d(TAG)
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_details);

        studentIndex = getIntent().getIntExtra("Student Index", 0);
        TextView tv = findViewById(R.id.display_string_id);

        String origStr = (String) tv.getText();
        tv.setText(origStr + studentIndex);
        tv.setTextSize(24);

        sObj = StudentDB.getInstance().getStudentList().get(studentIndex);

        EditText editView = findViewById(R.id.s_first_name_id);
        editView.setText(sObj.getFirstName());
        editView.setEnabled(false);
        editView = findViewById(R.id.s_last_name_id);
        editView.setText(sObj.getLastName());
        editView.setEnabled(false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.detail_screen_menu, menu);
        menu.findItem(R.id.action_edit).setVisible(true);
        menu.findItem(R.id.action_done).setVisible(false);
        detailMenu = menu;

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.action_edit){
            EditText editView = findViewById(R.id.s_first_name_id);
            editView.setEnabled(true);
            editView = findViewById(R.id.s_last_name_id);
            editView.setEnabled(true);

            item.setVisible(false);
            detailMenu.findItem(R.id.action_done).setVisible(true);
        }else if(item.getItemId() == R.id.action_done){
            EditText editView = findViewById(R.id.s_first_name_id);
            StudentDB.getInstance().getStudentList().get(studentIndex).setFirstName(editView.getText().toString());
            editView.setEnabled(false);
            editView = findViewById(R.id.s_last_name_id);
            StudentDB.getInstance().getStudentList().get(studentIndex).setLastName(editView.getText().toString());
            editView.setEnabled(false);
            item.setVisible(false);
            detailMenu.findItem(R.id.action_edit).setVisible(true);
        }
        return super.onOptionsItemSelected(item);
    }
}
